import React from "react";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      {/* <h1>Hello CodeSandbox</h1>  */}
      {/* <h2>Start editing to see some magic happen!</h2>  */}
      <div className="sidenav">
        <a href="#about" className="edit">
          Account Overview
        </a>
        <a href="#services" className="edit1">
          Edit Profile
        </a>
      </div>
      <div className="main">
        <h1>Acccount Overview</h1>
        <h2>Profile</h2>
        <h4>
          Username:<span>Suraj Kumar</span>
        </h4>
        <h4>
          Email: <span>sk123@gmail.com</span>
        </h4>
        <h4>
          Phone No: <span>9823992010</span>
        </h4>

        <button type="submit" className="button">
          Edit Profile
        </button>
        <button type="submit" className="button button1">
          Sign Out
        </button>
      </div>
    </div>
  );
}
